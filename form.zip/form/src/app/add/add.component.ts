import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {DemoService} from '../demo.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
   add=new FormGroup({
	name: new FormControl(''),
     last: new FormControl(''),
	email: new FormControl(''),
	address: new FormControl('')
	})





  constructor( private demo :DemoService) { }

  ngOnInit(): void {
  }

   collect(){
 	
}


}
