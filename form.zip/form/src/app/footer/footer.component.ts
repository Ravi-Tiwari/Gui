import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {DemoService} from '../demo.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

add=new FormGroup({
	name: new FormControl(''),
     last: new FormControl(''),
     age:new FormControl(''),
	email: new FormControl(''),
	address: new FormControl(''),
	phone:new FormControl('')
	})

 showModal: boolean;

 
  constructor(private demo:DemoService) { 
this.showModal = false;

  }

    show()
  {
    this.showModal = true; // Show-Hide Modal Check
    
  }
 hide()
  {
    this.showModal = false;
  }

  ngOnInit(): void {
  }

  collect(){


 this.demo.save(this.add.value).subscribe((result)=>{

 })
 this.add.reset()

 	
}


}
