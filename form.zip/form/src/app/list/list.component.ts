import { Component, OnInit } from '@angular/core';
import {DemoService} from '../demo.service'

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private demo:DemoService) { }
  collection:any=[];

  ngOnInit(): void {

this.demo.getlist().subscribe((result)=>{
console.log(result)
this.collection=result;
 })
}


}